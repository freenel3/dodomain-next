#!/bin/bash
# Скрипт для деплоя проекта dodomain

set -e

echo "🚀 Начинаем деплой проекта dodomain..."

# Переход в директорию проекта
cd /var/www/dodomain

# 1. Загрузка изменений с git
# echo "📥 Загрузка изменений с git..."
# git pull origin master

# 2. Остановка контейнеров
echo "🛑 Остановка контейнеров..."
docker compose down

# 3. Применение миграций базы данных
echo "🗄 Применение миграций базы данных..."
docker compose exec -T postgres psql -U dodomain -d dodomain < scripts/seed-data.sql

# 4. Пересборка и запуск контейнеров
echo "🔨 Пересборка и запуск контейнеров..."
docker compose up -d --build

# 5. Ожидание запуска контейнеров
echo "⏳ Ожидание запуска контейнеров..."
sleep 30

# 6. Проверка статуса контейнеров
echo "✅ Проверка статуса контейнеров..."
docker ps

# 7. Проверка работы сайта
echo "🌐 Проверка работы сайта..."
curl -s -o /dev/null -w "%{http_code}" http://localhost:3000/api/health || echo "Health check failed"

echo "✅ Деплой завершен успешно!"
echo "🌐 Сайт доступен по адресу: https://dodomain.ru"
